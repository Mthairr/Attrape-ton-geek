<!DOCTYPE html>
<html>

    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Attrape ton geek</title>
        <link rel="stylesheet" href="css/signup.css">
        <meta name="description" content="">
        <link rel="icon" href="favicon2.ico" sizes="any">
    </head>
    
    <body>
    <p>
        L'accès du site n'est pas autorisé aux moins de 18 ans.
    </p>
        <script src="js/app.js"></script>
        <script src="js/signup.js"></script>
    </body>
</html>
